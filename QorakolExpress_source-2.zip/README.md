# Qorako‘l Express
Oddiy Android prototip: buyurtma berish, status va profil.
APK yaratish uchun Android Studio orqali Gradle bilan build qiling.
