package uz.qorakol.express

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.view.ViewGroup

class MainActivity : android.app.Activity() {
    lateinit var box: LinearLayout
    val green = Color.rgb(22,138,69)
    fun tv(t:String, s:Float=18f): TextView = TextView(this).apply {
        text=t; textSize=s; setTextColor(Color.DKGRAY); setPadding(20,16,20,16)
    }
    fun btn(t:String, f:()->Unit)=Button(this).apply {
        text=t; setTextColor(Color.WHITE); setBackgroundColor(green)
        setOnClickListener{f()}; layoutParams=LinearLayout.LayoutParams(-1,60).apply{setMargins(20,8,20,8)}
    }
    override fun onCreate(b:Bundle?) { super.onCreate(b); home() }
    fun base(title:String) {
        box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL
        box.setBackgroundColor(Color.WHITE)
        val bar=TextView(this); bar.text=title; bar.textSize=25f; bar.setTextColor(Color.WHITE)
        bar.gravity=Gravity.CENTER_VERTICAL; bar.setPadding(20,0,0,0); bar.setBackgroundColor(green)
        box.addView(bar, LinearLayout.LayoutParams(-1,70)); setContentView(box)
    }
    fun home() {
        base("Qorako‘l Express")
        box.addView(tv("Tez va oson dastavka",24f))
        box.addView(tv("📦 Buyurtmangizni bir necha bosishda bering."))
        box.addView(btn("📦  BUYURTMA BERISH"){order()})
        box.addView(btn("🛵  BUYURTMA HOLATI"){status()})
        box.addView(btn("👤  PROFIL"){profile()})
    }
    fun order() {
        base("Buyurtma berish")
        val from=EditText(this); from.hint="Qayerdan olish"
        val to=EditText(this); to.hint="Qayerga olib borish"
        val item=EditText(this); item.hint="Nima olib boriladi"
        val phone=EditText(this); phone.hint="Telefon raqam"
        listOf(from,to,item,phone).forEach{box.addView(it,LinearLayout.LayoutParams(-1,65).apply{setMargins(20,5,20,5)})}
        box.addView(btn("BUYURTMA BERISH"){ 
            Toast.makeText(this,"Buyurtma qabul qilindi!",Toast.LENGTH_LONG).show(); status()
        })
        box.addView(btn("← ORQAGA"){home()})
    }
    fun status() {
        base("Buyurtma holati")
        box.addView(tv("🟡  Buyurtma qabul qilindi",21f))
        box.addView(tv("🛵  Kuryer tayyorlanmoqda"))
        box.addView(tv("🟢  Yetkazilgach shu yerda ko‘rinadi"))
        box.addView(btn("← BOSH SAHIFA"){home()})
    }
    fun profile() {
        base("Profil")
        box.addView(tv("👤 Mening profilim",22f))
        box.addView(tv("Ism: —"))
        box.addView(tv("Telefon: —"))
        box.addView(tv("Buyurtmalar tarixi: 0 ta"))
        box.addView(btn("← BOSH SAHIFA"){home()})
    }
}
